#ifndef boolean_H
#define boolean_H
/***********************************/
/* Program   : boolean.h */
/* Deskripsi : header file modul boolean */
/* NIM/Nama  : 24060120130106/Fahrel Gibran Alghany */
/* Tanggal   : 09/09/2021 */
/***********************************/

//type boolean enumerasi bahasa C, false=0, true=1
typedef enum {false, true} boolean;

#endif
